export default function Contact() {
  return (
    <section id="contact" className="py-20 text-center">
      <h2 className="text-3xl font-bold">Contact Me</h2>
      <p className="text-gray-400 mt-4">mailpratik01@gmail.com</p>
    </section>
  );
}