import { projects } from "../data/projects";
import { motion } from "framer-motion";

export default function Projects() {
  return (
    <section id="projects" className="py-20 px-6">
      <h2 className="text-3xl font-bold mb-6">Projects</h2>

      <div className="grid md:grid-cols-2 gap-6">
        {projects.map((p, i) => (
          <motion.div key={i} whileHover={{scale:1.05}} className="bg-gray-900 p-6 rounded-xl">
            <h3 className="text-xl font-semibold">{p.title}</h3>
            <p className="text-gray-400 mt-2">{p.description}</p>
            <a href={p.github} className="text-blue-400 mt-2 inline-block">
              View Code →
            </a>
          </motion.div>
        ))}
      </div>
    </section>
  );
}