import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="h-screen flex flex-col justify-center items-center text-center">
      <motion.h1 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="text-5xl font-bold">
        Pratik Shinde
      </motion.h1>
      <motion.p initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="text-gray-400 mt-4">
        Java Backend Developer | Spring Boot | REST APIs
      </motion.p>
    </section>
  );
}