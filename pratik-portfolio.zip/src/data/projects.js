export const projects = [
  {
    title: "FileCloud",
    description:
      "Secure file storage system with JWT authentication and analytics dashboard.",
    github: "https://github.com/pratik-png",
  },
  {
    title: "Traveller Management System",
    description:
      "RESTful backend with CRUD operations and email integration.",
    github: "https://github.com/pratik-png",
  },
];